from dash import Dash, html, dcc, callback, Output, Input,State
import plotly.express as px
import pandas as pd
from sqlalchemy import create_engine
import pandas as pd
from sqlalchemy import text
import plotly.graph_objs as go
import matplotlib.pyplot as plt
import random
import dash
from dash import callback_context
from dash.dependencies import Input, Output, MATCH, ALL
# Replace the placeholders with your actual database details
DATABASE_NAME = 'postgres'
DB_USER = 'postgres'
DB_PASSWORD = 'postgres'
DB_HOST = 'localhost'
DB_PORT = '5433'

# Create the SQLAlchemy connection string
data_connection = f"postgresql+psycopg2://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DATABASE_NAME}"

# Now you can use 'data_connection' to connect to your database using SQLAlchemy
engine = create_engine(data_connection)

app = Dash(__name__)


###############################     HOME PAGE    ###############################
page_1_layout = html.Div([
    html.H1("Uncover the emotion behind the reviews", style={'textAlign': 'center','background-color': 'white',
                                                             'margin-bottom': '0px'}),
    html.A(
        html.Img(src="assets/sentiment.png", width="100%")
    ),
    html.Div([
        html.Div([
            html.A(
                html.Img(src="assets/main1.png", width="100%", style={'cursor': 'pointer'}),href ="/customer_page"
            )
        ], style={'display': 'inline-block', 'width': '25%', 'margin-right': '100px'}),  
        html.Div([
            html.A(
                html.Img(src="assets/main2.png", width="100%", style={'cursor': 'pointer'}),href ="/company_page"
            )
        ], style={'display': 'inline-block', 'width': '25%'})
    ], style={'text-align': 'center'}) 
], style={"height":"100%",'background-color': '#F9F9F9'})

###############################     CUSTOMER PAGE    ###############################
page_2_layout = html.Div([
    html.H1("Write the product name", style={'textAlign': 'center', 'margin-bottom': '0px'}),

    html.Div([
        dcc.Input(id='my-input', type='text', placeholder='Enter product name'),
    html.Button('Submit', id='my-button', n_clicks=0)
    ] , style={"margin-top":"5%",'textAlign': 'center'}),

    html.Div([
        dcc.Graph(id='customer_data'),
        html.Div(id='pie_text', style={'margin-left': '20px'})
    ], style={'display': 'flex'})
    
    
], style={"height":"100%",'background-color': '#F9F9F9'})

###############################     COMPANY PAGE    ###############################

page_3_layout = html.Div([
    dcc.Store(id='product-names', data={}),
    html.H1("Write the company name", style={'textAlign': 'center', 'margin-bottom': '0px'}),

    html.Div([
        dcc.Input(id='my-input2', type='text', placeholder='Enter product name'),
    html.Button('Submit', id='my-button 2', n_clicks=0)
    ] , style={"margin-top":"5%",'textAlign': 'center'}),
    html.Div(id='dd-output-container'),
    dcc.Graph(id='line-plot'),
    dcc.Dropdown(id='product-dropdown', style={'width': '300px', 'margin-left': '20px'}),
    
    html.Div([
        html.Div(id='pie_text2', style={'margin-left': '20px'}),
        dcc.Graph(id='pie-plot2'),
    ], style={'display': 'flex'}),

    html.Div([
        dcc.Graph(id='stack_graph'),
        html.Div(id="clickdata")
    ], style={'display': 'flex'})
    
], style={"height":"100%",'background-color': '#F9F9F9'})

# Callback to update page content
@app.callback(
    Output("page-content", "children"),
    [Input("url", "pathname")]
)
def display_page(pathname):
    if pathname == "/":
        return page_1_layout
    elif pathname == "/customer_page":
        return page_2_layout
    elif pathname == "/company_page":
        return page_3_layout
    else:
        return page_1_layout
    
# App layout
app.layout = html.Div([
    dcc.Location(id="url", refresh=False),
    html.Div(id="page-content")
])

###############################     CLIENTE PAGE SEARCH   ###############################
@app.callback(
    Output('customer_data', 'figure'),
    [Input('my-button', 'n_clicks')],
    [State('my-input', 'value')]
)
def update_output(n_clicks, input_value):
    if n_clicks is not None:
        # Execute the SQL query with the updated product name
        query = text(f"""
            SELECT rp.*
            FROM reviews rp
            JOIN products p ON rp.product_fk = p.pk
            WHERE p.product_name = '{input_value}'
        """)
        with engine.connect() as connection:
            result = connection.execute(query)
            df = pd.DataFrame(result.fetchall(), columns=result.keys())

       # Assuming 'polarity' is the column containing polarity values
        # Assuming 'polarity' is the column containing polarity values
        polarity_counts = df['polarity'].value_counts()

        # Calculate the total count of polarity values
        total_count = polarity_counts.sum()

        # Calculate the percentage for each polarity value
        polarity_percentages = (polarity_counts / total_count) * 100

        # Define colors for each polarity
        colors = {-1: 'red', 0: 'grey', 1: 'green'}

        # Map the polarity values to their corresponding colors
        color_map = polarity_percentages.index.map(colors).tolist()

        # Create a pie chart using Plotly
        fig = go.Figure(data=[go.Pie(labels=polarity_percentages.index,
                                    values=polarity_percentages.values,
                                    marker_colors=color_map)])

        # Show both label (name) and percentage on hover
        fig.update_traces(hoverinfo='label+percent')

        return fig





@app.callback(
    Output('pie_text', 'children'),
    Input('customer_data', 'clickData'),
    State('my-input', 'value')
)
def display_value(click_data, input):
    if click_data:
        label = click_data['points'][0]['label']
        # Execute the SQL query with the updated product name
        query = text(f"""
            SELECT rp.*
            FROM reviews rp
            JOIN products p ON rp.product_fk = p.pk
            WHERE p.product_name = '{input}'
        """)
        with engine.connect() as connection:
            result = connection.execute(query)
            df = pd.DataFrame(result.fetchall(), columns=result.keys())

        # Assuming 'polarity' is the column containing polarity values
        df_filtered = df[df['polarity'] == int(label)]

        # Get up to 10 random reviews (if available)
        random_reviews = random.sample(df_filtered["text"].tolist(), min(10, len(df_filtered)))

        # Create a scrollable div for random reviews
        reviews_div = html.Div(
            children=[
                html.H4(f"Reviews for Polarity: {label}")
            ] + [
                html.P(review, style={'margin': '10px 0'}) for review in random_reviews
            ],
            style={'overflowY': 'scroll'}
        )

        return reviews_div
    else:
        return "Click a slice!"

###############################     COMPANY PAGE SEARCH   ###############################
@app.callback(
    [Output('product-dropdown', 'options'),
     Output('product-dropdown', 'value')],
    [Input('my-button 2', 'n_clicks')],
    [State('my-input2', 'value')]
)
def update_list_and_plot(n_clicks, input_value):
    # Add the new item to the list
    if n_clicks is not None:
        # Execute the SQL query with the updated product name Microsoft
        query = text(f"""
            SELECT DISTINCT pr.product_name, pr.pk
            FROM products pr
            WHERE pr.pk IN (
                SELECT p.product_fk
                FROM part_review p
                JOIN manufecture m ON p.manufacture_fk = m.pk
                WHERE m.manufecturer_name = '{input_value}'
            )
        """)
        with engine.connect() as connection:
            result = connection.execute(query)
            df = pd.DataFrame(result.fetchall(), columns=result.keys())

        # Create a list of options for the dropdown
        options_list = [{'label': row["product_name"], 'value': row["pk"]} for index, row in df.iterrows()]
        # Set the default value of the dropdown to the first option
        default_value = options_list[0]['value'] if options_list else None

        return options_list, default_value
    else:
        return [], None


@callback(
    [Output('line-plot', 'figure'),
     Output('pie-plot2', 'figure')],
    [Input('product-dropdown', 'value'),
     Input('product-dropdown', 'label')]
)
def update_output2(value,value2):
    if value != None:
        query = text(f"""
                    SELECT t.day, t.month, t.year, r.polarity
                        FROM reviews r
                        JOIN "TIME" t ON t.pk = r.time_fk
                        WHERE r.product_fk = '{value}'
            """)
        
        with engine.connect() as connection:
                result = connection.execute(query)
                df = pd.DataFrame(result.fetchall(), columns=result.keys())

        # Convert day, month, year to string
        df['day'] = df['day'].astype(str)
        df['month'] = df['month'].astype(str)
        df['year'] = df['year'].astype(str)

        # Combine day, month, year into a single date column
        df['date'] = df['day'] + '-' + df['month'] + '-' + df['year']

        # Convert 'date' to datetime
        df['date'] = pd.to_datetime(df['date'], format='%d-%m-%Y')
        df = df.sort_values(by='date')
        # Create a line chart
        figure = go.Figure(
            data=[
                go.Scatter(
                    x=df['date'],
                    y=df['polarity'],
                    mode='lines',
                    name='Polarity over Time',
                )
            ],
            layout=go.Layout(
                title='Polarity over Time',
                xaxis=dict(title='Date'),
                yaxis=dict(title='Polarity'),
            )
        )
        # Execute the SQL query with the updated product name
        query2 = text(f"""
            SELECT rp.*
            FROM reviews rp
            JOIN products p ON rp.product_fk = p.pk
            WHERE p.pk = '{(value)}'
        """)
        #print(query2)  # Print the query

        with engine.connect() as connection:
            result2 = connection.execute(query2)
            #print(result2.fetchall())  # Print the result
            df2 = pd.DataFrame(result2.fetchall(), columns=result2.keys())

        # Assuming 'polarity' is the column containing polarity values
        polarity_counts = df2['polarity'].value_counts()

        # Calculate the total count of polarity values
        total_count = polarity_counts.sum()

        # Calculate the percentage for each polarity value
        polarity_percentages = (polarity_counts / total_count) * 100
        #print(df2)
        # Define colors for each polarity
        colors = {-1: 'red', 0: 'grey', 1: 'green'}

        # Map the polarity values to their corresponding colors
        color_map = polarity_percentages.index.map(colors).tolist()

        # Create a pie chart using Plotly
        fig2 = go.Figure(data=[go.Pie(labels=polarity_percentages.index,
                                      values=polarity_percentages.values,
                                      marker_colors=color_map)])

        # Show both label (name) and percentage on hover
        fig2.update_traces(hoverinfo='label+percent')

        return figure,fig2

    return go.Figure(
            layout=go.Layout(
                title='Polarity over Time',
                xaxis=dict(title='Date'),
                yaxis=dict(title='Polarity'),
                annotations=[
                    dict(
                        text='No product selected',
                        showarrow=False,
                        xref='paper',
                        yref='paper',
                        x=0.5,
                        y=0.5
                    )
                ]
            )
        ), go.Figure(
            layout=go.Layout(
                annotations=[
                    dict(
                        text='No product selected',
                        showarrow=False,
                        xref='paper',
                        yref='paper',
                        x=0.5,
                        y=0.5
                    )
                ]
            )
        )



@app.callback(
    Output('pie_text2', 'children'),
    [Input('pie-plot2', 'clickData'),
    Input('product-dropdown', 'value')]
)
def display_value(click_data, input):
    if click_data:
        label = click_data['points'][0]['label']
        # Execute the SQL query with the updated product name
        query = text(f"""
            SELECT rp.*
            FROM reviews rp
            JOIN products p ON rp.product_fk = p.pk
            WHERE p.pk = {input}
        """)
        with engine.connect() as connection:
            result = connection.execute(query)
            df = pd.DataFrame(result.fetchall(), columns=result.keys())

        # Assuming 'polarity' is the column containing polarity values
        df_filtered = df[df['polarity'] == int(label)]

        # Drop duplicates
        df_filtered = df_filtered.drop_duplicates(subset=['text'])

        # Create a scrollable div for reviews
        # Create a scrollable div for reviews
        reviews_div = html.Div(
            children=[
                html.H4(f"Reviews for Polarity: {label}")
            ] + [
                html.P(review, style={'margin': '10px 0'}) for review in df_filtered["text"].tolist()
            ],
            style={'overflowY': 'scroll', 'height': '400px'}
        )
        return reviews_div
    else:
        return "Click on the pie chart to get reviews of the product filtered by the sentiment."




@app.callback(
    Output('stack_graph', 'figure'),
    Input('product-dropdown', 'value')
)
def update_graph(selected_dropdown_value):
    if selected_dropdown_value is not None:
        # SQL query
        query = text(f"""
            SELECT pr.polarity, pp.product_part
            FROM part_review pr
            JOIN products p ON pr.product_fk = p.pk
            JOIN products_parts pp ON pr.product_part_fk = pp.pk     
            WHERE p.pk = {selected_dropdown_value}
        """)
        
        # Execute query and fetch results into a DataFrame
        with engine.connect() as connection:
            result = connection.execute(query)
            df = pd.DataFrame(result.fetchall(), columns=result.keys())
        
        # Convert polarity to string for color encoding in Plotly Express
        df['polarity'] = df['polarity'].map({-1: 'Polarity -1', 0: 'Polarity 0', 1: 'Polarity 1'})

        # Define colors for each polarity
        colors = {'Polarity -1': 'red', 'Polarity 0': 'grey', 'Polarity 1': 'green'}

        # Create a Plotly Express bar chart
        fig = px.bar(df, x='product_part', y='polarity', color='polarity', title='Polarity Counts by Product Part', color_discrete_map=colors)

        # Increase the size of the graph
        fig.update_layout(autosize=False, width=1000, height=800)

        return fig
    return go.Figure(
            layout=go.Layout(
                annotations=[
                    dict(
                        text='No product selected',
                        showarrow=False,
                        xref='paper',
                        yref='paper',
                        x=0.5,
                        y=0.5
                    )
                ]
            )
        )


@app.callback(
    Output('clickdata', 'children'),
    Input('stack_graph', 'clickData'),
    State('product-dropdown', 'value')
)
def display_click_data(clickData, selected_dropdown_value):
    if clickData is not None:
        # Extract the clicked part and polarity from the clickData
        clicked_part = clickData['points'][0]['x']
        clicked_polarity = clickData['points'][0]['y'].split(" ")[1]
        clicked_part = clickData['points'][0]['label']
        query = text(f"""
            SELECT pr.text
            FROM part_review pr
            JOIN products p ON pr.product_fk = p.pk
            JOIN products_parts pp ON pr.product_part_fk = pp.pk     
            WHERE (p.pk = {selected_dropdown_value} AND pr.polarity = {clicked_polarity} AND pp.product_part = '{clicked_part}')
        """)
        # Execute query and fetch results into a DataFrame
        with engine.connect() as connection:
            result = connection.execute(query)
            df = pd.DataFrame(result.fetchall(), columns=result.keys())
        # Drop duplicates
        df = df.drop_duplicates()
        # Create a scrollable div for reviews
        reviews_div = html.Div(
            children=[
                html.P(review, style={'margin': '10px 0'}) for review in df["text"]
            ],
            style={'overflowY': 'scroll', 'height': '700px'}
        )
        return reviews_div
    else:
        return 'Click on a part to see its details'

    
if __name__ == "__main__":
    app.run_server(debug=True)
# Microsoft Surface Pro 4